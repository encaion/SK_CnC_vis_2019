library("ggplot2")

df = data.frame(xx = 1:10,
                yy = 10:1)

ggplot(data = df, 
       mapping = aes(x = xx, y = yy)) + 
  geom_point()

ggplot(df, aes(x = xx, y = yy)) + 
  geom_point()

ggplot() + 
  geom_point(data = df,
             aes(x = xx, y = yy))

ggplot(df, aes(x = xx, y = yy)) + 
  geom_point(size = 6)

ggplot(df, aes(x = xx, y = yy)) + 
  geom_point(size = 6) + 
  geom_line()

ggplot(df, aes(x = xx, y = yy)) + 
  geom_point(size = 6) + 
  geom_line(color = "#FFFFFF")

ggplot(df, aes(x = xx, y = yy)) + 
  geom_point(size = 6) + 
  geom_line(color = "#FFFFFF",
            size = 3)

ggplot(df, aes(x = xx, y = yy)) + 
  geom_point(size = 6) + 
  geom_line(color = "#FFFFFF",
            linewidth = 3)

ggplot(df, aes(x = xx, y = yy)) + 
  geom_point(size = 6) + 
  geom_line(color = "#FFFFFF",
            linewidth = 3) + 
  geom_col()

ggplot(df, aes(x = xx, y = yy)) + 
  geom_col() + 
  geom_point(size = 6) + 
  geom_line(color = "#FFFFFF",
            linewidth = 3)

df = diamonds
head(df, 2)

ggplot(data = aggregate(data = df,
                        price ~ cut + color,
                        FUN = "mean"),
       aes(x = cut, y = price, fill = color)) + 
  geom_col()

df_agg = aggregate(data = df,
                   price ~ cut + color,
                   FUN = "mean")
ggplot(data = df_agg,
       aes(x = cut, y = price, fill = color)) + 
  geom_col()

ggplot(data = df_agg,
       aes(x = cut, y = price, fill = color)) + 
  geom_col(position = "dodge")

ggplot(data = df_agg,
       aes(x = cut, y = price, fill = color)) + 
  geom_col(position = "fill")


head(df, 2)

cor.test(df$carat, df$price)

ggplot(data = df,
       aes(x = carat, y = price)) + 
  geom_point()

ggplot(data = df,
       aes(x = carat, y = price, color = color)) + 
  geom_point()

ggplot(data = df,
       aes(x = carat, y = price, color = color)) + 
  geom_point(alpha = 0.2) # 0.2x = 1


head(df, 2)
df[, "price_c"] = df$price / df$carat
df_sub = df[, c("cut", "color", "price_c")]
head(df_sub, 3)

df_sub_agg = aggregate(data = df_sub,
                       price_c ~ cut + color,
                       FUN = "mean")
ggplot(data = df_sub_agg,
       aes(x = cut, y = price_c, fill = color)) + 
  geom_col(position = "dodge")


df = as.data.frame(diamonds)

ggplot(data = df,
       aes(x = cut, y = price, color = cut)) + 
  geom_boxplot()

ggplot(data = df,
       aes(x = cut, y = price)) + 
  geom_boxplot(color = "red")


ggplot(data = df,
       aes(x = cut, y = price, fill = cut)) + 
  geom_boxplot()

ggplot(data = df,
       aes(x = cut, y = price, fill = cut)) + 
  geom_boxplot(color = "#FF0000")


ggplot(data = df,
       aes(x = price)) + 
  geom_histogram()

ggplot(data = df,
       aes(x = price)) + 
  geom_histogram(fill = "#FFFFFF", color = "#000000")

ggplot(data = df,
       aes(x = price, fill = ..count..)) + 
  geom_histogram()

ggplot(data = df,
       aes(x = price, fill = after_stat(count))) + 
  geom_histogram()

ggplot(data = df,
       aes(x = price, fill = after_stat(count))) + 
  geom_histogram(bins = 100) + 
  scale_fill_gradientn(colors = c("#63B0F2", "#8DCBF2",
                                  "#0D4023", "#15592D", 
                                  "#448C30"))

# ggplot(data = df,
#        aes(x = price, fill = price)) + 
#   geom_histogram(bins = 100) + 
#   scale_fill_gradientn(colors = c("#63B0F2", "#8DCBF2",
#                                   "#0D4023", "#15592D", 
#                                   "#448C30"))

ggplot(data = df,
       aes(x = price, fill = after_stat(count))) + 
  geom_histogram(bins = 100) + 
  scale_fill_gradientn(colors = c("#63B0F2", "#448C30"))

ggplot(data = df,
       aes(x = price, fill = after_stat(count))) + 
  geom_histogram(binwidth = 2500) + 
  scale_fill_gradientn(colors = c("#63B0F2", "#448C30"))


ggplot(diamonds, aes(depth, fill = cut, color = cut)) + 
  geom_density(alpha = 0.1) + 
  xlim(55, 70) + 
  theme_bw()

ggplot(diamonds, aes(depth, fill = cut, color = cut)) + 
  geom_density(alpha = 0.1) + 
  theme_bw()

ggplot(diamonds, aes(depth, fill = cut, color = cut)) + 
  geom_density(alpha = 1) + 
  xlim(55, 70) + 
  theme_bw()

ggplot(diamonds, aes(depth, fill = cut, color = cut)) + 
  geom_density(alpha = 0.1) + 
  xlim(55, 70)

gg = ggplot(diamonds, aes(depth, fill = cut, color = cut)) + 
  geom_density(alpha = 0.1) + 
  xlim(55, 70) + 
  theme_bw()

gg + 
  theme(legend.position = "none")

gg + 
  theme(legend.position = "bottom")

gg + 
  theme(legend.position = c(0.75, 0.7))

gg + 
  labs(fill = "Cut", color = "Cut")

gg + 
  ggtitle("Title!!!")

gg + 
  labs(title = "Title",
       subtitle = "subtitle",
       x = "x-axis",
       y = "y-axis",
       fill = "Cut(fill)",
       color = "Cut(color)",
       caption = "caption")

gg + 
  labs(title = "Title",
       subtitle = "subtitle") + 
  theme(plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5))


gg + 
  labs(title = "Title",
       subtitle = "subtitleads;lasdjfals;djfsla;djfsaldfkjsdkfjlsdf") + 
  theme(plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5))

gg + 
  labs(title = "Title",
       subtitle = "subtitle\nnext line") + 
  theme(plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5))

gg + 
  labs(x = "") # x축제목이 지워진 것 같지만 공간이 할당되어있음

gg + 
  labs(x = NULL)

gg + 
  labs(x = "") + 
  theme(axis.title.x = element_blank())


df = read.csv("2021년 서울청년패널조사(1차) 데이터_R교육용(230214).csv")
df_sub = df[, c("AGE", "A1")]
37 %/% 10 # 나눗셈의 몫

df_sub[, "AGE_g"] = df_sub$AGE %/% 10 * 10
head(df_sub)

df_sub_agg = aggregate(data = df_sub,
                       A1 ~ AGE_g, FUN = "mean")
df_sub_agg

ggplot(data = df_sub_agg,
       aes(x = AGE_g, y = A1)) + 
  geom_col()

ggplot(data = df_sub_agg,
       aes(x = AGE_g, y = A1, fill = AGE_g)) + 
  geom_col()

df_sub_agg[, "AGE_g2"] = as.character(df_sub_agg$AGE_g)
ggplot(data = df_sub_agg,
       aes(x = AGE_g2, y = A1, fill = AGE_g2)) + 
  geom_col()

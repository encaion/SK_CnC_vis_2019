df = read.csv("2021년 서울청년패널조사(1차) 데이터_R교육용(230214).csv")
colnames(df)
df$WS[1:4]

# 영문자로 시작하고 숫자 1~2자리로 끝나는 변수명 추출
df_sub = df[, c(grep("^[A-Za-z][0-9]{1,2}$", colnames(df), value = TRUE),
                "WS")]
head(df_sub, 2)

class(df_sub$A5)
table(df_sub$A5)
df_sub$A5[1000:1005]
num_A5 = as.numeric(df_sub$A5[1000:1005])
vec_ws = df_sub$WS[1000:1005]

for(n_col in colnames(df_sub)[-ncol(df_sub)]){
  print(n_col)
}
colnames(df_sub)[ncol(df_sub)]

for(n_col in colnames(df_sub)[-ncol(df_sub)]){
  # n_col = "A1"
  print(n_col)
  df_sub[, n_col] = as.numeric(df_sub[, n_col])
  df_sub[, n_col] = df_sub[, n_col] * df_sub$WS
}
head(df_sub, 2)

df_stats = apply(X = df_sub, MARGIN = 2, 
                 FUN = "mean", na.rm = TRUE)
df_stats = data.frame(col = names(df_stats),
                      val = df_stats)
head(df_stats, 2)

df_stats_sub = df_stats[df_stats$val < 10, ]

library("ggplot2")
ggplot(data = df_stats_sub,
       aes(x = col, y = val)) + 
  geom_col()

plot(1:5, 1:5)


# install.packages("ggplot2")
library("ggplot2")
qplot(1:4, 1:4)

df = data.frame(xx = 1:4, yy = 1:4)
# 스타일 1
ggplot(data = df, 
       mapping = aes(x = xx, y = yy)) + 
  geom_point()

# 스타일 2
ggplot() + 
  geom_point(data = df, 
             mapping = aes(x = xx, y = yy))


ggplot(data = df, 
       mapping = aes(x = xx, y = yy)) + 
  geom_line()

ggplot(data = df, 
       mapping = aes(x = xx, y = yy)) + 
  geom_col()


ggplot(data = df, 
       mapping = aes(x = xx, y = yy)) + 
  geom_line() + 
  geom_point(size = 5)


df = data.frame(xx = 1:8,
                yy = c(5, 1, 2, 3, 7, 5, 6, 3))

ggplot(data = df,
       aes(x = xx, y = yy, fill = yy)) + 
  geom_col()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
  geom_col(fill = "blue")

colors()

ggplot(data = df,
       aes(x = xx, y = yy)) + 
  geom_col(fill = "navajowhite3")

grep(pattern = "blue", x = colors(), value = TRUE)

ggplot(data = df,
       aes(x = xx, y = yy)) + 
  geom_col(fill = "#0000FF")

ggplot(data = df,
       aes(x = xx, y = yy)) + 
  geom_col(fill = "#AAAAFF")


b <- ggplot(seals, aes(x = long, y = lat))
b + geom_curve(aes(yend = lat + 1,
                   xend = long + 1), curvature = 1) 

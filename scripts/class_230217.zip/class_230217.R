getwd()

# asdkfjh
# 주석(comment)

# 1. 시작하기 ####

list.files()

install.packages("beepr")
library("beepr")
beep(2)

beepr::beep(2)

install.packages("data.table")
library("data.table")

list.files()
# df = read.csv("C:/Users/encai/desktop/rclass/bike.csv")
df = read.csv("bike.csv")
head(df, 2)

# install.packages("readxl")
library("readxl")
df_xl = read_excel("iris_xlsx.xlsx")
head(df_xl, 2)

write.csv(iris, "iris_row_true.csv")
write.csv(iris, "iris_row_false.csv", 
          row.names = FALSE)

df = read.csv("temp_sensor.csv")
head(df, 2)

write.csv(df, "temp_sensor_write.csv",
          row.names = FALSE)

?head
help(head)

library("data.table")

getwd()

c(1, 2, 3)
c("a", 2, 3)
aa = c(3, 4, 5)
aa
aa[1]
aa[c(1, 3)]
aa[3] = "bbb"
aa





head(1:8)

beep(2)
library("beepr")
beep(2)

"서울시,관악구"

df = read.csv("bike.csv")
head(df, 2)
class(df)

library("data.table")
df2 = fread("bike.csv")
head(df2, 2)
class(df2)

library("readr")
df3 = read_csv("bike.csv")
head(df3, 2)
class(df3)

?head

c(1, 2, 3)
c("A", 3, 5)

data.frame(v1 = 1:4,
           v2 = c("a", "b", "c", "d"))
data.frame(v1 = 1:3,
           v2 = c("a", "b", "c", "d"))
df = data.frame(v1 = 1:4,
                v2 = c("a", "b", "c", "d"))
df

df = data.frame("aa" = 1:4,
                "bb" = c("a", "b", "c", "d"))
df

df$aa # df 객체의 aa 변수의 모든 원소
df[, "aa"] # 쉼표 앞에 비워둔 것은 모든 row 선택
df$aa[1] # df 객체의 aa 변수의 첫 번째 원소
df$aa[1:2]
df$aa[c(1, 2)]
df[1, 2]
df[1, 1]
df[1, "aa"] # df$aa[1]

df[1:3, ]
df[c(1, 3), ]

df2 = df[, c(2, 1)]
df2

bike = read.csv("bike.csv")
head(bike, 2)

bike_sub = bike[c(1, 3, 5), c("temp", "casual")]
bike_sub

head(bike, 2)
colnames(bike)
colnames(bike)[7]
colnames(bike)[c(1, 3, 5)]
colnames(bike)[2:6]

colnames(bike)[1]
colnames(bike)[1] = "dt"
head(bike, 2)

colnames(bike)[c(3, 4)] = c("hday", "wday")
head(bike, 2)


df = data.frame(aa = 1:3,
                bb = 3:5)
df[, "new_col"] = df$aa * df$bb
# df$new_col = df$aa * df$bb
df

df[, "new2"] = 2
df

# df2 = df
# df = df2

df[, "bb"] = 100
df

head(bike, 2)

bike_day = bike[, grep(pattern = "day$", x = colnames(bike))]
bike_day = bike[, c("workingday", "holiday")]
head(bike_day, 2)

df = data.frame(aa = 1:3,
                bb = letters[1:3])
df

df[c(1, 3), ]
df[c(TRUE, FALSE, TRUE), ]
df[df$aa != 2, ] # not equal(같지 않음.)
# df 객체에서 df 객체의 aa 변수의 원소가 2가 아닌 row를 필터링

df[(df$aa == 3) | (df$bb == "b"), ] # A 조건 또는 B 조건 만족
df[(df$aa >= 2) & (df$bb == "c"), ] # A 조건과 B 조건 둘 다 만족
# df[df$aa >= 2 & df$bb == "c", ]

bike = read.csv("bike.csv")
head(bike, 2)

# Q. season이 3이면서 temp가 20 이상인 데이터를 필터링.
bike_sub = bike[(bike$season == 3) & (bike$temp >= 20), ]
nrow(bike_sub)

unique(bike$season)
table(bike$season) # count
prop.table(table(bike$season))
table(bike$season, bike$holiday)
table(season = bike$season, 
      holiday = bike$holiday)
table(bike[, c("season", "holiday")])

df = airquality
aggregate(data = df, Wind ~ Month, FUN = "mean")

aggregate(data = bike, temp ~ season, FUN = "mean")
aggregate(data = bike, temp ~ season + holiday, FUN = "mean")

head(bike)

bike_sub = bike[1:6, c("temp", "atemp")]
bike_sub
apply(bike_sub, MARGIN = 1, FUN = "diff")
apply(bike_sub, MARGIN = 2, FUN = "max")

bike_sub[, "diff"] = apply(bike_sub, MARGIN = 1, FUN = "diff")
bike_sub[, "diff2"] = bike_sub$atemp - bike_sub$temp
bike_sub

as.numeric("1234")
as.character(1241)

grepl(pattern = "a", c("aa", "Bb"))
!grepl(pattern = "a", c("aa", "Bb"))

getwd()

#### if() ####
3 == 3
"a" == "b"
c("a", "b", "c") == "c"

if(TRUE){
  print(123)
}
# if() 함수의 소괄호 내부에는
# 반드시 하나의 TRUE 또는 FALSE가 할당되어야 한다.

if(TRUE){
  print(123)
} else {
  print(456)
}

if(FALSE){
  print(123)
} else {
  print(456)
}

# if(TRUE){
#   # TRUE일 때 실행되는 코드
# } else {
#   # FALSE일 때 실행되는 코드
# }

a = 100

if(a == 100){
  print(123)
} else {
  print(456)
}

if(a == 100){
  print(123)
}

for(n in 1:3){
  print(n)
}

for(n in 3:1){
  print(n)
}

for(kkkk in 1:3){
  print(kkkk)
}

df = read.csv("bike.csv")
head(df, 2)

for(df in 1:4){
  print(df)
}

head(df, 2)

for(n in 1:4){
  print("====")
  for(i in 100:102){
    print(i)
  }
  print(n)
}

for(i in 1:4){
  print("====")
  for(i in 100:102){
    print(i)
  }
  print(i)
}


df_1 = data.frame(aa = letters[1:4],
                  bb = 1:4)

for(num in 1:4){
  df_1[num, "new_column"] = num * 2
  print(df_1)
  Sys.sleep(2)
}

df_2 = data.frame(aa = letters[1:4],
                  bb = 1:4)
df_2[, "new"] = df_2$bb * 2
df_2


vec = 1:6
vec

ifelse(test = vec == 1, yes = "yes", no = "no")
ifelse(vec == 1, "yes", "no")
ifelse(vec >= 3, yes = "yes", no = "no")
ifelse(vec >= 3, yes = 999, no = vec)
ifelse(vec >= 3, yes = vec, no = 999)

df_iris = iris
head(df_iris, 2)
df_iris[, "is_setosa"] = ifelse(df_iris$Species == "setosa",
                                yes = 1, no = 0)
table(df_iris[, c("Species", "is_setosa")])

df_iris[, "is_2"] = ifelse(df_iris$Species %in% c("setosa", "versicolor"),
                           yes = 1, no = 0)
table(df_iris[, c("Species", "is_2")])


rbind(head(iris, 2), tail(iris, 2))

df_i1 = iris[1:2, 1:3]
df_i2 = iris[1:2, 2:4]
df_i3 = iris[1:2, 1:4]
df_i4 = iris[1:2, 3:5]

rbind(df_i1, df_i2)
rbind(df_i1, df_i3)
rbind(df_i1, df_i4)

df_i2_2 = df_i2
colnames(df_i2_2) = colnames(df_i1)

df_i4_2 = df_i4
colnames(df_i4_2) = colnames(df_i1)

rbind(df_i1, df_i2_2)
rbind(df_i1, df_i4_2)
df_bind = rbind(df_i1, df_i4_2)
summary(df_bind)

cbind(df_i1, df_i1)

cbind(iris[1:2, 1:2], iris[2:4, 1:2])
cbind(iris[1:2, 1:2], iris[2:5, 1:2])

df = read.csv("2021년 서울청년패널조사(1차) 데이터_R교육용(230214).csv")
head(df, 2)

length(unique(df$PID))
nrow(df)
df[1:3, 1:6]
# length()

table(df$AGE)

dir.create("panel_2021_age")
list.files(pattern = "2021")

df = read.csv("2021년 서울청년패널조사(1차) 데이터_R교육용(230214).csv")
df = df[, 2:ncol(df)]

vec_age = unique(unique(df$AGE))
vec_age[1]

df_sub = df[df$AGE == vec_age[1], ]
unique(df_sub$AGE)
nrow(df_sub)

paste0("panel_2021_age/2021_panel_1st_age_", vec_age[1], ".csv")

for(n_age in vec_age){
  df_sub = df[df$AGE == n_age, ]
  file_path = paste0("panel_2021_age/2021_panel_1st_age_", n_age, ".csv")
  write.csv(df_sub, file_path, row.names = FALSE)
}
list.files(path = "panel_2021_age/")

vec_file_path = list.files(path = "panel_2021_age/",
                           full.names = TRUE)
vec_file_path

df_sub = read.csv(vec_file_path[1])
head(df_sub, 1)

df_bind = data.frame()
for(n_file in 1:length(vec_file_path)){
  df_sub = read.csv(vec_file_path[n_file])
  df_bind = rbind(df_bind, df_sub)
  print(nrow(df_bind))
}

df_A = data.frame(v1 = c("a", "b", "c"),
                  v2 = c(100, 200, 300))
df_B = data.frame(v1 = c("a", "c"),
                  v2 = c(999, 777))

library("dplyr")
left_join(x = df_A, y = df_B, by = c("v1" = "v1"))
inner_join(x = df_A, y = df_B, by = c("v1" = "v1"))


df = data.frame(obs = 1:4,
                v1 = c("aaa", "bbb", "abc", "abc@gmail.com"))
df

df[, "cnt"] = nchar(df$v1)
df[, "v2"] = gsub(pattern = "a", replacement = "x", df$v1)
df

grep(pattern = "b", x = df$v1)
df[grep(pattern = "b", x = df$v1), ]

df$v1[grep(pattern = "b", x = df$v1)]
df[grep(pattern = "b", x = df$v1), "v1"]

grep(pattern = "b", x = df$v1, value = TRUE)
grepl(pattern = "b", x = df$v1)

TRUE
FALSE
TRUE + 0
TRUE + FALSE
TRUE + TRUE
sum(c(TRUE, TRUE, FALSE))

sum(grepl(pattern = "b", x = df$v1))
# df 객체의 v1 변수의 원소에 b가 포함된 것의 개수

sum(df$v1 == "bbb")

!TRUE
!c(TRUE, FALSE)
!grepl(pattern = "b", x = df$v1)

df[!grepl(pattern = "b", x = df$v1), ]

# install.packages("splitstackshape")
library("splitstackshape")

v_split = strsplit(df$v1,
                   split = "@") # 기본함수.. 결과는 list 로 나옴.
v_split[[4]]
v_split[[4]][2]

df_split = cSplit(df, splitCols = "v1", sep = "@")
df_split = as.data.frame(df_split)
df_split

df_split = cSplit(df, splitCols = "v1", sep = "@", 
                  drop = FALSE)
df_split = as.data.frame(df_split)
df_split

df$v1
substr(df$v1, start = 2, stop = 4)
# 2023-01-01

substr("2023-02-24", start = 6, stop = 7)

"[5-7]"

vec1 = c("23000원", "15,000원", "250$", "0.123%", "25ml")
vec1

grep(pattern = "원$", x = vec1, value = TRUE)
grep(pattern = "%$", x = vec1, value = TRUE)
grep(pattern = "\\$$", x = vec1, value = TRUE)

# 0으로 시작하는~
grep(pattern = "^0", x = vec1, value = TRUE)
# 정각까지 쉬는시간입니다~
gsub(pattern = "원", replacement = "", vec1)
gsub(pattern = "원|,", replacement = "", vec1)
gsub(pattern = "원|,|\\$", replacement = "", vec1)

gsub(pattern = "[0-9]", replacement = "", vec1)
gsub(pattern = "[^0-9]", replacement = "", vec1)
gsub(pattern = "[^0-9.]", replacement = "", vec1)

as.numeric(gsub(pattern = "[^0-9.]", replacement = "", vec1)) / 20

gsub(pattern = "[^0-9.a-z]", replacement = "", vec1)


gsub(pattern = "^[0-9].*?[a-z]$", # 숫자로 시작하고 영문 소문자로 끝남
     replacement = "", vec1)

# install.packages("lubridate")
library("lubridate")
# months()
Sys.Date()
months(Sys.Date())
months(Sys.Date(), abbreviate = TRUE)
as.numeric(months(Sys.Date(), abbreviate = TRUE))

month(Sys.Date())

as_date("2023년 2월 24일", format = "%Y년 %m월 %d일")
as_date("2023년 2월 24일")
as_date("2023a 2b 24c")

time1 = Sys.time()
time1

year(time1)
hour(time1)
date(time1)
wday(time1)
wday(time1, label = TRUE)
wday(time1, label = TRUE, abbr = FALSE)
wday(time1, label = TRUE, week_start = 1) # 시작이 월요일

df = read.csv("2021년 서울청년패널조사(1차) 데이터_R교육용(230214).csv",
              fileEncoding = "UTF-8")
head(df, 2)
nrow(df)
ncol(df)
colnames(df)

t(t(colnames(df)))

df_K = df[, grep(pattern = "^K", colnames(df))]
head(df_K, 2)

df_D = df[, grep(pattern = "^D", colnames(df))]
df_D_not_d = df_D[, !grepl(pattern = "dummy", colnames(df_D))]
head(df_D_not_d, 2)
# 변수명이 D로 시작하고, dummy가 없는

df_D_num = df[, grep(pattern = "^D[0-9]{1,}$", colnames(df))]
head(df_D_num, 2)
# 변수명이 D로 시작하고, 숫자(0~9)가 뒤에 이어서 1개 이상 반복
#  + 숫자로 끝남

df_caps = df[, grep(pattern = "^[A-Z][0-9]{1,}$", colnames(df))]
head(df_caps, 2)

df_D9 = df[, grep(pattern = "^D9", colnames(df))]
head(df_D9, 2)

df_time = df[, c("day", "time1", "time2")]
head(df_time)

df_time[, "dt"] = paste(df_time$day, df_time$time2, sep = " ")
head(df_time, 2)
class(df_time$dt)

df_time[, "dt2"] = as_datetime(df_time$dt)
class(df_time$dt2)
head(df_time, 2)

df_time[, "time1"] = ifelse(df_time$time1 == 2, yes = 12, no = 0)
df_time[, "hour"] = hour(df_time$dt2)
df_time[, "hour"] = df_time$hour + df_time$time1
hour(df_time[, "dt2"]) = df_time$hour
head(df_time, 2)



library("ggplot2")

df_p = data.frame(xx = 1:10,
                  yy = 1:10)
df_p

gg1 = ggplot(data = df_p, aes(x = xx, y = yy)) + 
  geom_point(size = 4)
gg1       

gg1 + 
  annotate(geom = "text", size = 10, label = "ㅋㅋㅋ",
           x = 3, y = 7) + 
  geom_vline(xintercept = 3) + 
  geom_hline(yintercept = 7) + 
  annotate(geom = "text", size = 10, label = "ㅋㅋㅋㅋㅋ",
           x = 3, y = 6)

gg1 + 
  annotate(geom = "rect", 
           xmin = 6, xmax = 8,
           ymin = 2, ymax = 4,
           linewidth = 2, color = "#FF0000",
           fill = "#00FF00", alpha = 0.5) + 
  annotate(geom = "segment",
           x = 5, y = 5, xend = 4, yend = 7.5) + 
  annotate(geom = "text", size = 4, label = "A Team",
           x = 4, y = 7.8)


gg1 + 
  geom_vline(xintercept = 2:5) + 
  geom_hline(yintercept = 2:5)


gg1 + 
  geom_text(aes(y = yy + 1, label = yy))

ggplot(data = df_p,
       aes(x = xx, y = yy, fill = yy)) + 
  geom_col() +
  geom_text(aes(y = yy + 0.5, label = yy)) + 
  theme_bw() +
  theme(legend.position = "none")


ggplot(data = df_p,
       aes(x = xx, y = yy, fill = yy)) + 
  geom_col() +
  geom_text(data = df_p[8:10, ],
            aes(x = xx, y = yy + 0.5, label = yy)) + 
  theme_bw() +
  theme(legend.position = "none")

ggplot(data = df_p,
       aes(x = xx, y = yy, fill = yy)) + 
  geom_col() +
  geom_text(data = df_p[8:10, ],
            aes(x = xx, y = yy -0.5, label = yy),
            fontface = "bold", size = 5, 
            color = "#FFFFFF") + 
  theme_bw() +
  theme(legend.position = "none")


ggplot() + 
  geom_rect(aes(xmin = seq(1, 10, 2),
                xmax = seq(2, 10, 2),
                ymin = 0, ymax = 10),
            fill = "#FF0000", alpha = 0.2) + 
  geom_point(data = df_p,
             aes(x = xx, y = yy), size = 2)

dia = as.data.frame(diamonds)
head(dia, 2)

ggplot(data = dia,
       aes(x = carat, y = price)) + 
  geom_point(color = "#0000FF", alpha = 0.2)

ggplot(data = dia,
       aes(x = carat, y = price)) + 
  geom_point(color = "#0000FF", alpha = 0.2) + 
  facet_grid(cols = vars(color))

ggplot(data = dia,
       aes(x = carat, y = price)) + 
  geom_point(color = "#0000FF", alpha = 0.2) + 
  facet_grid(cols = vars(color)) + 
  theme_bw() + 
  theme(panel.grid.major.x = element_blank(),
        panel.grid.minor = element_blank())

ggplot(data = dia,
       aes(x = carat, y = price)) + 
  geom_point(color = "#0000FF", alpha = 0.2) + 
  facet_grid(cols = vars(color),
             scales = "free_x") + 
  theme_bw() + 
  theme(panel.grid.major.x = element_blank(),
        panel.grid.minor = element_blank())


ggplot(data = dia,
       aes(x = carat, y = price)) + 
  geom_point(color = "#0000FF", alpha = 0.2) + 
  facet_wrap(facets = ". ~ color",
             nrow = 2)


ggplot(data = dia,
       aes(x = carat, y = price)) + 
  geom_point(color = "#0000FF", alpha = 0.2) + 
  facet_wrap(facets = ". ~ color",
             nrow = 2,
             strip.position = "left") + 
  theme_bw() +
  theme(strip.background = element_rect(colour = "#000000",
                                        fill = "#FFFFFF"))
  

library("ggplot2")
library("ggExtra")

set.seed(30)
df = data.frame(x = rnorm(500, 50, 10),
                 y = runif(500, 0, 50))
p = ggplot(df, aes(x, y)) + 
  geom_point(color = "#FFAACC",
             size = 5, alpha = 0.4) + 
  theme_bw()
ggMarginal(p, 
           type = "densigram",
           fill = "#FF0000",
           color = "#0000FF")


p2 = ggplot(iris, aes(x = Petal.Length,
                      y = Petal.Width,
                      color = Species)) + 
  geom_point(size = 5, alpha = 0.4) + 
  theme_bw() + 
  theme(legend.position = c(0.85, 0.2))
ggMarginal(p2, type = "density", 
           groupFill = TRUE,
           groupColour = TRUE)

library("rgdal")
# 저는 map 폴더를 새로 만들고
# 다운로드 받은 지도파일을 해당 폴더에 압축을 풀었음
list.files("map")
map = readOGR("map/ctp_rvn.shp")
class(map)
slotNames(map)

# sp::plot(map)

# df$col1
# list1[["a1"]]
map@data
df_map_data = map@data
df_map_data[, "CTP_KOR_NM"] = iconv(df_map_data$CTP_KOR_NM,
                                    from = "CP949",
                                    to = "UTF-8")
df_map_data

map@polygons[[1]]

library("ggplot2")
df_map = fortify(map)
head(df_map)

ggplot(data = df_map,
       aes(x = long, y = lat, 
           group = group, color = id)) + 
  geom_polygon(fill = "#FFFFFF") + 
  theme_void() + 
  theme(legend.position = "none",
        panel.border = element_rect(size = 0.5,
                                    fill = "transparent")) 
  

ggplot(data = df_map,
       aes(x = long, y = lat, 
           group = group, color = id)) + 
  geom_polygon(fill = "#FFFFFF") + 
  theme(legend.position = "none")

unique(df_map$id)
ggplot(data = df_map[df_map$id == "0", ],
       aes(x = long, y = lat, 
           group = group, color = id)) + 
  geom_polygon(fill = "#FFFFFF") + 
  theme(legend.position = "none")

head(df_map_data)

ggplot(data = df_map[df_map$long <= 1200000, ],
       aes(x = long, y = lat, 
           group = group, color = id)) + 
  geom_polygon(fill = "#FFFFFF") + 
  theme(legend.position = "none")

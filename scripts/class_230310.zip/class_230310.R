library("ggplot2")

bike = read.csv("bike.csv")
head(bike, 2)

library("lubridate")
# 2011년 8월
bike[, "datetime"] = as_datetime(bike$datetime)
bike[, "year" ] =  year(bike$datetime)
bike[, "month"] = month(bike$datetime)
bike_sub = bike[(bike$year == 2011) & (bike$month == 8), ]
head(bike_sub)

bike_sub2 = bike_sub[1:150, ]
ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  theme(panel.grid.major = element_line(color = "#FF0000")) + 
  theme(panel.grid.major = element_line(color = "#0000FF"))

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  theme_bw()

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  theme(panel.grid.major = element_line(color = "#0000FF")) +
  theme_bw()

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  theme_bw() + 
  theme(panel.grid.major = element_line(color = "#0000FF"))


ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  theme_bw() + 
  theme(panel.grid.major = element_line(color = "#0000FF",
                                        linewidth = 1.5),
        panel.grid.minor = element_line(color = "#FF0000"))

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_hline(yintercept = 350, linewidth = 2, color = "#FFAACC") + 
  geom_line()

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  theme(panel.border = element_rect(linewidth = 2))

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  theme(panel.border = element_rect(linewidth = 2,
                                    color = "#000000",
                                    fill = alpha('#000000', 0)))

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  theme(panel.border = element_rect(linewidth = 2,
                                    fill = "transparent"))

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  theme(panel.border = element_rect(linewidth = 2,
                                    fill = "transparent"),
        panel.background = element_rect(fill = "#00FFCC"),
        plot.background = element_rect(fill = "#FFAACC"))

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  scale_x_datetime(breaks = "day")

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  scale_x_datetime(date_breaks = "day", 
                   date_labels = "%m월 %d일")

ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  scale_x_datetime(date_breaks = "day", 
                   date_labels = "%m월 %d일") + 
  theme_bw() + 
  theme(panel.grid.major.x = element_line(color = "#FF0000"))


ggplot(data = bike_sub2,
       aes(x = datetime, y = count)) + 
  geom_line() + 
  scale_x_datetime(date_breaks = "2 day", # 숫자 뒤에 한 칸 띄어쓰기.
                   date_labels = "%m월 %d일") + 
  theme_bw() + 
  theme(panel.grid.major.x = element_line(color = "#FF0000"))


head(bike_sub)
######################################################
bike = read.csv("bike.csv")
bike[, "datetime"] = as_datetime(bike$datetime)
bike[, "year" ] =  year(bike$datetime)
bike[, "month"] = month(bike$datetime)
bike_sub_agg = aggregate(data = bike,
                         count ~ year + month, 
                         FUN = "mean")
head(bike_sub_agg)

bike_sub_agg[, "ym"] = paste(bike_sub_agg$year, 
                             sprintf(fmt = "%02d", bike_sub_agg$month),
                             sep = "-")
head(bike_sub_agg, 2)

ggplot(data = bike_sub_agg,
       aes(x = ym, y = count)) + 
  geom_col()
######################################################

ggplot(data = bike_sub_agg,
       aes(x = ym, y = count, fill = count)) + 
  geom_col() + 
  theme_bw() + 
  theme(panel.grid.minor = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.grid.major.y = element_line(linewidth = 2),
        legend.position = "none")


ggplot(data = bike_sub_agg,
       aes(x = ym, y = count, fill = count)) + 
  geom_col() + 
  theme_bw() + 
  theme(panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank(),
        panel.grid.major.x = element_line(linewidth = 2),
        legend.position = "none") + 
  coord_flip()

ggplot(data = bike_sub_agg,
       aes(x = ym, y = count, fill = count)) + 
  geom_col() + 
  scale_y_continuous(expand = c(0.01, 0.01)) + 
  theme_bw() + 
  theme(panel.grid.minor = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.grid.major.y = element_line(linewidth = 2),
        legend.position = "none")


ggplot(data = bike_sub_agg,
       aes(x = ym, y = count, fill = count)) + 
  geom_col() + 
  scale_y_continuous(expand = c(0.01, 0.01),
                     limits = c(0, max(bike_sub_agg$count) * 1.05)) + 
  theme_bw() + 
  theme(panel.grid.minor = element_blank(),
        panel.grid.major.x = element_blank(),
        panel.grid.major.y = element_line(linewidth = 2),
        legend.position = "none")

ggplot() + 
  geom_col(aes(x = "", y = 1:3, fill = 1:3))

ggplot() + 
  geom_col(aes(x = "", y = 1:3, fill = 1:3)) + 
  coord_polar(theta = "y")

ggplot() + 
  geom_col(aes(x = "", y = 1:3, fill = 1:3)) + 
  coord_polar(theta = "y") + 
  theme_void()

ggplot() + 
  geom_col(aes(x = "", y = 1:3, fill = 1:3)) + 
  coord_polar(theta = "y") + 
  theme(panel.grid = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        legend.position = "none",
        panel.background = element_blank())

# install.packages("webr")
library("webr")
library("dplyr")
df = as.data.frame(Titanic)
df %>% 
  group_by(Class, Survived) %>%
  summarise(n = sum(Freq)) -> PD

PieDonut(data = PD, 
         aes(Class, Survived, count=n))


dia = as.data.frame(diamonds)
head(dia, 2)

ggplot(data = dia,
       aes(x = price)) + 
  geom_histogram(binwidth = 1000,
                 fill = "#DDDDDD", color = "#000000") + 
  theme_bw()

dia[, "price_1k"] = dia$price %/% 1000
head(dia, 2)

dia_p_cnt = as.data.frame(table(dia$price_1k))
head(dia_p_cnt, 2)

ggplot(data = dia_p_cnt,
       aes(x = Var1, y = Freq)) + 
  geom_col()

ggplot(data = dia,
       aes(x = cut, y = price)) + 
  geom_boxplot(outlier.color = "#FF0000",
               outlier.alpha = 0.2,
               outlier.shape = "x",
               outlier.size = 4)


df1 = data.frame(xx = 1:8,
                 yy = 1:8)
ggplot(data = df1, 
       aes(x = xx, y = yy, color = yy)) + 
  geom_point(size = 8,
             shape = "★")

ggplot(data = df1, 
       aes(x = xx, y = yy, color = yy)) + 
  geom_point(size = 8,
             shape = "헐")


ggplot(data = df1, 
       aes(x = xx, y = yy, fill = yy)) + 
  geom_col()

ggplot(data = df1, 
       aes(x = reorder(xx, yy, decreasing = TRUE),
           y = yy, fill = yy)) + 
  geom_col()

df2 = data.frame(dep = c("a", "b", "c", "d"),
                 perf = c(100, 300, 200, 400))
ggplot(data = df2,
       aes(x = dep, y = perf, fill = dep)) + 
  geom_col()

df2 = data.frame(dep = c("b", "a", "c", "d"),
                 perf = c(300, 100, 200, 400))
df2 = df2[order(df2$perf), ]
ggplot(data = df2,
       aes(x = dep, y = perf, fill = dep)) + 
  geom_col()

ggplot(data = df2,
       aes(x = reorder(dep, perf), 
           y = perf, fill = dep)) + 
  geom_col()

ggplot(data = df2,
       aes(x = reorder(dep, perf, decreasing = TRUE), 
           y = perf, fill = dep)) + 
  geom_col()

# install.packages("patchwork")
library("patchwork")

gg = ggplot(data = df2,
            aes(x = dep, y = perf, fill = dep)) + 
  geom_col()
gg

gg + gg
(gg + gg) / gg
